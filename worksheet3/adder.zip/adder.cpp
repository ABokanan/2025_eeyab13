//begin -- adder.cpp ----------

#include "adder.h"

int add( int a, int b) {
return a + b;
}

//end -- adder.cpp --------