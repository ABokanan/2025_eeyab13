//begin -- adder.h -----

#ifndef MATHSLIB_ADDER_H
#define MATHSLIB_ADDER_H

//prototype for our function
int add(int a,int b);
#endif
//end -- adder.h -----
